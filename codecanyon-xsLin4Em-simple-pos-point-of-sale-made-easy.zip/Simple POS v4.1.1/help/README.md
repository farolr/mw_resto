## Simple POS - Point of Sale Made Easy

### We have tried to prepare comprehensive documentation for [Simple POS - Point of Sale Made Easy](http://codecanyon.net/item/simple-pos-point-of-sale-made-easy/3947976/?ref=Tecdiary)

###### View Links: [rawgit](http://rawgit.com/tecdiary/spos-guide/gh-pages/index.html) | [gh-pages](http://tecdiary.github.io/spos-guide/)

Please read this documentation before asking us anything. As you know the support is no more free, you might need to pay $5 for any question that is already listed in the documentation. So save your money, read the documentation. If you can't find the answer then you can contact us by emailing to support@tecdiary.com 

Thank you